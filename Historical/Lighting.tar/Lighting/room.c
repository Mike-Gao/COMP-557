#include <stdio.h>
#include <math.h>
#include <GL/glut.h>
#include <GL/glext.h>

extern float lightPos[3];

void drawSquare( float size ) {
    glBegin(GL_QUADS);
    glNormal3f(0.0f, 0.0f, 1.0f);
    glVertex3f( 0.0*size, 0.0*size, 0.0);
    glVertex3f( 1.0*size, 0.0*size, 0.0);
    glVertex3f( 1.0*size, 1.0*size, 0.0);
    glVertex3f( 0.0*size, 1.0*size, 0.0);
    glEnd();
}

void drawSphere( float size )
{
    glutSolidSphere(size, 32, 32);
}

#define GL_WIN_WIDTH     512 
#define GL_WIN_HEIGHT    512

#define NUMTILE   20

void drawSceneNoMirror()
{   int  i,j;

    float pos0[] = {0.0, 0.0, 0.0, 1.0};
    float yellowlight[] = {1.0, 1.0, 0.0, 1.0};
    float whitelight[] = {1.0, 1.0, 1.0, 1.0};
    float ambient[] = {0.8, 0.0, 0.0, 1.0};
    float diffuse[] = {0.8, 0.0, 0.0, 1.0};
    float noemission[] = {0.0, 0.0, 0.0, 0.0};

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse);
    
    glPushMatrix();
    glTranslatef(lightPos[0], lightPos[1], lightPos[2]);
    glLightfv(GL_LIGHT0, GL_POSITION, pos0);
    
    glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, yellowlight);
    
    glutSolidSphere(0.4, 20, 20);
    glPopMatrix();

    glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, noemission);

    //  draw floor

    glPushMatrix();
    glTranslatef(-10.0, -2.0, 0.0);  	
    glRotatef(-90.0, 1.0, 0.0, 0.0);
    drawSquare(20.0);
    glPopMatrix();

    //  draw ceiling

    glPushMatrix();
    glTranslatef(-10.0, 18.0, 0.0);  	
    glRotatef(-90.0, 1.0, 0.0, 0.0);
    drawSquare(20.0);
    glPopMatrix();

   
    //  draw zFar wall

    glPushMatrix();
    glTranslatef(-10.0, -2.0, -20.0);  	
    drawSquare(20.0);
    glPopMatrix();

    //  draw wall behind camera

    glPushMatrix();
    glTranslatef(-10.0, -2.0, 0.0);  	
    drawSquare(20.0);
    glPopMatrix();

    //  draw left wall

    glPushMatrix();
    glTranslatef(-10.0, -2.0, -20.0);
    glRotatef(-90.0, 0.0, 1.0, 0.0);  	
    drawSquare(20.0);
    glPopMatrix();

    //  draw right wall

    glPushMatrix();
    glTranslatef(10.0, -2.0, -20.0);
    glRotatef(-90.0, 0.0, 1.0, 0.0);
    drawSquare(20.0);
    glPopMatrix();

}

void draw3DScene()
{   
  extern  GLdouble left, right, bottom, top, zNear,zFar;
  extern  float eye[3], rot[3];
  int i;

  //   Before this function is called,  the caller has already set the MODELVIEW matrix.

  glPushMatrix();
  glRotatef(rot[0], 1.0f, 0.0f, 0.0f);
  glRotatef(rot[1], 0.0f, 1.0f, 0.0f);
  glRotatef(rot[2], 0.0f, 0.0f, 1.0f);
  glTranslatef (-eye[0], -eye[1], -eye[2]);

  drawSceneNoMirror();
  glPopMatrix();

}

void init(void)
{
     glClearColor(0.0, 0.0, 0.0, 0.0);
     glEnable(GL_LIGHTING);
     glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);  //otherwise we've to orient the faces towards the light

     glEnable(GL_NORMALIZE);   // We want to use the *unit* normal vector for Phong shading.  
                               // The normal will not be of unit length if a glScale was used, since it 
                               // scales all points and vectors.   
                               // If we don't normalize the normal vector, then OpenGL gets the shading wrong.
     glEnable(GL_DEPTH_TEST);  
     glShadeModel(GL_SMOOTH);  //

}




