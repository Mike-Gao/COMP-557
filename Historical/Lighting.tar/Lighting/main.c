//
//  Base code for COMP-557 Assignment #1 
//  (adapted from basecode on www.nehe.gamedev.com)
//

#include <stdio.h>
#include <stdlib.h>
#include <GL/glut.h>
//#include <GL/glu.h>
#ifdef WIN32
#pragma comment(lib, "glut32.lib")
#endif
#define ESC '\033'

//  Creates a enum type for mouse buttons.

enum {
  BUTTON_LEFT,
  BUTTON_RIGHT,
  BUTTON_LEFT_CTRL,
  BUTTON_RIGHT_CTRL,
  BUTTON_LEFT_SHIFT,
  BUTTON_RIGHT_SHIFT
};

//  Global variables.

int mButton;
int mOldY, mOldX;
unsigned int showmirror;

//  Camera view volume parameters used to define view volume.

GLdouble zNear  =      1.0;    
GLdouble zFar   =     40.0;
GLdouble left  =    -1.0;
GLdouble right =     1.0;
GLdouble bottom =   -1.0;
GLdouble top    =    1.0;

float eye[3] = {0.0f, 10.0f, -3.0f};
float rot[3] = {0.0f, 0.0f, 0.0f};

float eye_EM[3] = {0.0f, 10.0f, -12.0f};
float rot_mirror[3] = {0.0f, 0.0f, 0.0f};

float lightPos[3] = {0.0f, 10.0f, -10.0f};
// windows size and position constants 

int GL_WIN_WIDTH  = 512;
int GL_WIN_HEIGHT = 512;
int GL_WIN_INITIAL_X = 0;
int GL_WIN_INITIAL_Y = 0;
int w;

// function prototypes  

void glutResize( int w, int h);
void glutKeyboard(unsigned char k, int x, int y);
void clamp(float *v);
void glutMotion(int x, int y);
void glutMouse(int button, int state, int x, int y);
void glutMenu(int value);
void glutDisplay(void);

void init();
void draw3DScene();
void drawEnvMap();
void draw3DCoordinateAxes();
void drawCube( float size );
void drawSphere( float size );
void drawLines( float size );
void drawSquare( float size );

void glutResize(int width, int height) {

 //   MIKE:  Don't allow for resizing of the window. 

  glViewport(0, 0, GL_WIN_WIDTH, GL_WIN_HEIGHT);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(left, right, bottom, top, zNear, zFar);
  //gluPerspective(45, 1.0, 0.1, 200);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  }

void glutIdle() {
	glFlush();
	glutPostWindowRedisplay(w);
}

//------------------------------------------------------------------------
// Function that handles input from the keyboard
//------------------------------------------------------------------------

void glutKeyboard(unsigned char key, int x, int y) {
  extern unsigned int showmirror;
  switch (key) {
  case ESC:
    exit(0);
    break;
  case 'm':
    showmirror +=1;
    break; 
  case 'u':
  case 'U':
      lightPos[1] += 0.1;
      break;
  case 'd':
  case 'D':
      lightPos[1] -= 0.1;
      break;
  case 'l':
  case 'L':
      lightPos[0] -= 0.1;
      break;
  case 'r':
  case 'R':
      lightPos[0] += 0.1;
      break;
  case 'b':
  case 'B':
      lightPos[2] += 0.1;
      break;
  case 'f':
  case 'F':
      lightPos[2] -= 0.1;
      break;



  }
}

//------------------------------------------------------------------------
// If rotation angle is greater of 360 or lesser than -360,
// reset angle back to zero.
//------------------------------------------------------------------------

void clamp(float *v) {
  int i;
  
  for (i = 0; i < 3; i ++)
    if (v[i] > 360 || v[i] < -360)
      v[i] = 0;
}

//------------------------------------------------------------------------
// Moves the camera based on mouse pressed button
//------------------------------------------------------------------------

void glutMotion(int x, int y) {

  //   RIGHT mouse button translates the camera in xz directions (world coordinates)
  //   LEFT  mouse button pan and tilts the camera 
  //   SHIFT_LEFT  translates the mirror in xy directions (world coordinates)
  //   SHIFT_RIGHT translates the mirror in z direction
  //   CTRL_LEFT and CTRL_RIGHT rotate the mirror.

  if (mButton == BUTTON_LEFT) {

    // pan or tilt camera

    rot[0] += y - mOldY;
    rot[1] += x - mOldX;   

    //    clamp (rot);
  }
  else if (mButton == BUTTON_RIGHT) {

    //     translates the camera in the x and z direction
    //     in world coordinates (not in camera coordinates)

    eye[0] += (mOldX - x) * 0.05f; 
    eye[2] += (mOldY - y) * 0.05f; 
    clamp (rot);
  } 

  //  translates the mirror sphere (left/right or up/down)

  else if (mButton == BUTTON_LEFT_SHIFT) {
    eye_EM[0] += (x - mOldX) * 0.01f;
    eye_EM[1] -= (y - mOldY) * 0.01f;
    lightPos[0] += (x - mOldX) * 0.01f;
    lightPos[1] -= (y - mOldY) * 0.01f;
  }

  //  translates the mirror sphere forward or backward

  else if (mButton == BUTTON_RIGHT_SHIFT) {
      eye_EM[2] += (y - mOldY) * 0.01f;
      lightPos[2] += (y - mOldY) * 0.01f;
  }
  else if (mButton == BUTTON_LEFT_CTRL) {
    rot_mirror[0] += (x - mOldX) * 0.1f;
    rot_mirror[1] -= (y - mOldY) * 0.1f;
  } 
  else if (mButton == BUTTON_RIGHT_CTRL) {
    rot_mirror[2] -= (y - mOldY) * 0.1f;
  } 

  mOldX = x;
  mOldY = y;
}

//------------------------------------------------------------------------
// Function that handles mouse input
//------------------------------------------------------------------------

void glutMouse(int button, int state, int x, int y) {

  if(state == GLUT_DOWN) {
    mOldX = x;
    mOldY = y;

    switch(button) {
    case GLUT_LEFT_BUTTON:
      if (glutGetModifiers() == GLUT_ACTIVE_CTRL) {
	    mButton = BUTTON_LEFT_CTRL;
      } else if(glutGetModifiers() == GLUT_ACTIVE_SHIFT) {
        mButton = BUTTON_LEFT_SHIFT;
      } else {
	  mButton = BUTTON_LEFT;
      }
      break;
    case GLUT_RIGHT_BUTTON:
      if (glutGetModifiers() == GLUT_ACTIVE_CTRL) {
	    mButton = BUTTON_RIGHT_CTRL;
      } else if(glutGetModifiers() == GLUT_ACTIVE_SHIFT) {
	mButton = BUTTON_RIGHT_SHIFT;
      } else {
	mButton = BUTTON_RIGHT;
      }
      break;
    }
    } 
  else if (state == GLUT_UP)
      mButton = -1;
}


// The glutDisplay is responsible for drawing to the window and is called
// whenever the window needs to be redrawn. 


void glutDisplay(void) {

  //  DRAW SCENE IN LEFT VIEWPORT
  glViewport(0,0, GL_WIN_WIDTH, GL_WIN_HEIGHT);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glFrustum(left, right, bottom, top, zNear, zFar);

  glMatrixMode(GL_MODELVIEW);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();	
  gluLookAt(0.0, 0.0, 0.0, 0.0, 0.0, -1.0, 0.0, 1.0, 0.0);

  draw3DScene();

  glutSwapBuffers();

}

int main(int argc, char** argv) {

	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH | GLUT_MULTISAMPLE);
	glutInit( &argc, argv );

	glutInitWindowPosition( GL_WIN_INITIAL_X, GL_WIN_INITIAL_Y );
	glutInitWindowSize(GL_WIN_WIDTH, GL_WIN_HEIGHT );
	w = glutCreateWindow("View from Camera + Environment Map");
	
	glutReshapeFunc(glutResize);       
	glutDisplayFunc(glutDisplay);      
	glutIdleFunc(glutIdle);            
	glutKeyboardFunc(glutKeyboard);    
	glutMouseFunc(glutMouse);          
	glutMotionFunc(glutMotion);        

	init();
	glutMainLoop();
	
	return 0;
}



